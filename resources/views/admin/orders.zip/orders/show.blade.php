@extends('admin.layout')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Detalle del Pedido #{{ $order->id }}</h2>
        <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Volver
        </a>
    </div>

    @if(session('success')) 
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div> 
    @endif

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white fw-bold py-3">
                    <i class="fas fa-box-open me-2 text-secondary"></i>Productos Solicitados
                </div>
                <div class="card-body p-0">
                    <table class="table mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Producto</th>
                                <th>Precio Unit.</th>
                                <th>Cantidad</th>
                                <th class="text-end pe-4">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items as $item)
                            <tr>
                                <td class="ps-4 fw-bold text-secondary">{{ $item->product_name }}</td>
                                <td>${{ number_format($item->price, 2) }}</td>
                                <td>{{ $item->quantity }}</td>
                                <td class="text-end pe-4 fw-bold text-dark">
                                    ${{ number_format($item->price * $item->quantity, 2) }}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="3" class="text-end fw-bold pt-3 text-uppercase">Total a Pagar:</td>
                                <td class="text-end pe-4 fw-bold text-danger fs-4 pt-3">
                                    ${{ number_format($order->total, 2) }}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            
            <div class="card shadow-sm border-0 mb-4 border-top border-4 border-success">
                <div class="card-header bg-white fw-bold py-3">
                    <i class="fas fa-money-bill-wave me-2 text-success"></i>Información de Pago
                </div>
                <div class="card-body">
                    <p class="mb-2 d-flex justify-content-between align-items-center">
                        <strong>Método:</strong> 
                        <span class="badge bg-dark text-uppercase">
                            {{ str_replace('_', ' ', $order->payment_method) }}
                        </span>
                    </p>
                    
                    @if($order->payment_reference)
                        <div class="alert alert-success py-2 mb-0 mt-3">
                            <small class="text-uppercase fw-bold text-success">Referencia / Comprobante:</small><br>
                            <span class="fs-5 fw-bold text-dark">
                                <i class="fas fa-receipt me-1"></i> {{ $order->payment_reference }}
                            </span>
                        </div>
                    @else
                        <div class="alert alert-light border py-2 mb-0 mt-3 text-center text-muted">
                            <small>No se requiere referencia (Efectivo/Punto)</small>
                        </div>
                    @endif
                </div>
            </div>

            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white fw-bold py-3">
                    <i class="fas fa-user me-2 text-secondary"></i>Datos del Cliente
                </div>
                <div class="card-body">
                    <p class="mb-2"><strong>Nombre:</strong> {{ $order->contact_name }}</p>
                    
                    <p class="mb-2"><strong>C.I. / RIF:</strong> {{ $order->user->cedula ?? 'No registrada' }}</p>
                    
                    <p class="mb-2">
                        <strong>Teléfono:</strong> 
                        <a href="https://wa.me/58{{ substr(preg_replace('/[^0-9]/', '', $order->contact_phone), 1) }}" target="_blank" class="text-decoration-none">
                            <i class="fab fa-whatsapp text-success"></i> {{ $order->contact_phone }}
                        </a>
                    </p>
                    
                    <hr>
                    
                    <p class="mb-1 fw-bold text-secondary small text-uppercase">Dirección de Entrega:</p>
                    <div class="alert alert-secondary p-2 m-0 small border-0">
                        <i class="fas fa-map-marker-alt text-danger me-1"></i> {{ $order->address }}
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0 border-top border-4 border-primary">
                <div class="card-header bg-white fw-bold py-3">
                    <i class="fas fa-tasks me-2 text-primary"></i>Gestionar Estado
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.orders.update', $order->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <label class="form-label small text-muted fw-bold">Estado Actual del Pedido:</label>
                        <select name="status" class="form-select mb-3">
                            <option value="pendiente" {{ $order->status == 'pendiente' ? 'selected' : '' }}>🟡 Pendiente (Por Despachar)</option>
                            <option value="completado" {{ $order->status == 'completado' ? 'selected' : '' }}>🟢 Completado (Entregado)</option>
                            <option value="cancelado" {{ $order->status == 'cancelado' ? 'selected' : '' }}>🔴 Cancelado</option>
                        </select>

                        <button type="submit" class="btn btn-primary w-100 fw-bold py-2">
                            <i class="fas fa-save me-2"></i>ACTUALIZAR ESTADO
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection